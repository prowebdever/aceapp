﻿namespace AceApp.Data
{
    public class AppSettings
    {
        public string AzureBlobConnectionString { get; set; }
        public string AzureBlobContainerName { get; set; }
    }
}
